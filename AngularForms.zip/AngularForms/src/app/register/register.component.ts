import { Component, OnInit } from '@angular/core';
import { FormGroup,FormControl,Validators } from '@angular/forms';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
name:string="";
age:number=0;
phone:number=0;
email:string="";
username:string="";
password:string="";
cpassword:string="";
regForm:FormGroup=new FormGroup({});
  constructor() { }

  ngOnInit(): void {
    this.regForm=new FormGroup({
      name:new FormControl("", [Validators.required]),
      age:new FormControl("", [Validators.required]),
      phone:new FormControl("", [Validators.required]),
      email:new FormControl("", [Validators.required]),
      
      username:new FormControl("", [Validators.required]),
      password:new FormControl("", [Validators.required]),
      cpassword:new FormControl("", [Validators.required])//we can initialize the values here
    });
  }
get Name(){
  return this.regForm.get("name");
}
get Age(){
  return this.regForm.get("age");
}get Phone(){
  return this.regForm.get("phone");
}get Email(){
  return this.regForm.get("email");
}get Username(){
  return this.regForm.get("username");
}get Password(){
  return this.regForm.get("password");
}get Cpassword(){
  return this.regForm.get("cpassword");
}



  regFun():void{
    console.log(this.regForm.value);
    console.log(this.regForm.get("username")?.value);
    console.log(this.regForm.get("password")?.value);
    
  }

}
