import { Component, OnInit } from '@angular/core';
import { FormGroup,FormControl } from '@angular/forms';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  username:string="";
  password:string="";
  loginForm:FormGroup=new FormGroup({});
//initialize with empty obj

  constructor() { }

  ngOnInit(): void {
    this.loginForm=new FormGroup({
      username:new FormControl("sharma"),
      password:new FormControl("124")//we can initialize the values here
    });
  }
  loginFun():void{
    console.log(this.loginForm.value);
    console.log(this.loginForm.get("username")?.value);
    console.log(this.loginForm.get("password")?.value);
    
  }

}
